import yfinance as yf
import pandas as pd

stock_id = 'AAPL'
data = yf.Ticker(stock_id)
historical_data = pd.DataFrame()

df = data.history(period='D', start='2019-1-1', end='2020-1-1')
df.head()

historical_data = pd.concat([historical_data, df])
historical_data.to_csv('AAPL_2019.csv')
